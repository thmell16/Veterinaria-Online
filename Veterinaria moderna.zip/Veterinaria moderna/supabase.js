const SUPABASE_URL = "https://srvdsqscycuwntcimcmt.supabase.co";
const SUPABASE_KEY = "sb_publishable_qEBYDhC745kMG89gBZv_jQ_Ih6Unq22";

const supabase = window.supabase.createClient(
  SUPABASE_URL,
  SUPABASE_KEY
);


