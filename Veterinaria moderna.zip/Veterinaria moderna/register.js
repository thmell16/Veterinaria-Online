// register.js
const supabaseUrl = 'https://srvdsqscycuwntcimcmt.supabase.co';
const supabaseKey = 'sb_publishable_qEBYDhC745kMG89gBZv_jQ_Ih6Unq22';

// Cliente Supabase (nombre distinto para evitar conflicto)
const supabaseClient = supabase.createClient(supabaseUrl, supabaseKey);

document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("registerForm");
  form.addEventListener("submit", register);
});

async function register(event) {
  event.preventDefault();

  const nombre = document.getElementById("nombre").value.trim();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();

  if (!nombre || !email || !password) {
    alert("Completa todos los campos");
    return;
  }

  const { error } = await supabaseClient.auth.signUp({
    email,
    password,
    options: {
      data: { nombre }
    }
  });

  if (error) {
    alert(error.message);
    console.error(error);
    return;
  }

  alert("Usuario registrado correctamente ✅");
  window.location.href = "login.html";
}

