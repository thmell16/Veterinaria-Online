// login.js
// Supabase ya viene del CDN
const supabaseUrl = 'https://srvdsqscycuwntcimcmt.supabase.co';
const supabaseKey = 'sb_publishable_qEBYDhC745kMG89gBZv_jQ_Ih6Unq22';
const supabase = supabase.createClient(supabaseUrl, supabaseKey);

document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("loginForm");
  form.addEventListener("submit", login);
});

async function login(event) {
  event.preventDefault();

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();

  if (!email || !password) {
    alert("Por favor, completa todos los campos");
    return;
  }

  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password
  });

  if (error) {
    alert("Datos incorrectos ❌");
    console.error(error);
    return;
  }

  alert("¡Bienvenido! 🎉");
  window.location.href = "index.html"; // Cambia a la página que quieras
}
